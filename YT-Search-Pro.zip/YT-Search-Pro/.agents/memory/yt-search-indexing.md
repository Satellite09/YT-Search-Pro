---
name: YouTube subscription indexing
description: Product architecture constraints for complete subscription-scoped retrieval.
---

Subscription-scoped retrieval must enumerate subscriptions and each channel's uploads playlist; it must not use YouTube `search.list`.

**Why:** Completeness within trusted channels is the product wedge, and uploads playlist enumeration is both more complete and far cheaper in quota.

**How to apply:** Keep a resumable 12-month local index, cache channel country metadata, expose partial results while indexing, and reserve `search.list` for explicitly metered global search.