---
name: Brave-compatible Google OAuth
description: Authentication architecture required for Brave-based extension users.
---

Brave authentication must use a server-mediated Google authorization-code flow, not `chrome.identity.getAuthToken` or a client-side implicit-token flow.

**Why:** Brave's identity implementation and Google's custom-URI restrictions make the native extension flow unreliable. Keeping the Web client secret server-side also prevents credential exposure.

**How to apply:** Validate the extension's HTTPS `chromiumapp.org` return URL, exchange Google codes on the API server, and redirect with a short-lived one-time ticket that the extension exchanges for an access token.